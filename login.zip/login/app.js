const express = require('express')
const session = require('express-session')
const FileStore = require('session-file-store')(session)
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')

// session存放地址，账号密码，sessionid找到用户

const app = express()

let identityKey = 'xrj'

let users = require('./users').items
// 验证是否账号正确
// 数组的find的使用方法，自动遍历
let findUser = (name, password) => {
  return users.find(item => {
    return item.name === name && item.password === password
  })
}
// console.log(users)
// console.log(findUser('xrj','123456'))
// console.log(findUser('Chyingp','123456'))

// 检验session，这是顺序
app.use(session({
  name: identityKey,
  // secret就是用来对session id相关的cookie 进行签名的
  secret: 'chyingp',
  store: new FileStore(),
  // 是否自动保存为初始化的会话
  saveUninitialized: false,
  // 是否每次重新保存
  resave: false,
  cookie: {
    //有效期
    maxAge: 10 * 1000
  }
}))

app.set('views', 'views/')
app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'))

app.use(bodyParser.json())
// 默认使用urlencoded的关闭
app.use(bodyParser.urlencoded({ extended: false }))
app.use(cookieParser())

app.get('/', (req, res, next) => {
  let sess = req.session
  let loginUser = sess.loginUser
  let isLogined = sess.loginUser?true:false
  console.log(sess.loginUser)
  res.render('index', {
    // 相对前端的全局变量
    name: loginUser ||'',
    isLogined
  })
})

app.post('/login', (req, res, next) => {
  //bodyParser的使用
  // console.log(req.body.name, req.body.password)
  let user = findUser(req.body.name, req.body.password)
  if (user) {
    // 种session
    // 重新生成一个sessess
    // 为你构建一个session
    req.session.regenerate((err) => {
      // 请求对象负责session的携带
      if (err) {
        return res.json(
          {
            ret_code: 2, // session失败了
            ret_msg: '登录失败'
          }
        )
      } else {
        req.session.loginUser = user.name
        console.log('session生成成功')
        res.json({
          ret_code: 0, //成功了
          ret_msg: '登录数据'
        })
      }
    })
    // res.json({
    //   ret_code: 0, //成功了
    //   ret_msg: '登录数据'
    // })
  } else {
    res.json({
      ret_code: 1, //失败了
      ret_msg: '账号密码出错了'
    })
  }
})

app.get('/logout',(req,res,next)=>{
  req.session.destroy((err)=>{
    if(err) {
      res.json({
        ret_code: 2,
        ret_msg: '退出登录失败'
      })
      return
    } else {
      res.clearCookie(identityKey)
      res.redirect('/')
    }
  })
})

app.listen(3000, () => {
  console.log('listening on port 3000')
})