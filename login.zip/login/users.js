module.exports = {
  items: [
    {
      name: 'Chyingp',
      password: '123456'
    },
    {
      name: 'xrj',
      password: '123456'
    }
  ]
}